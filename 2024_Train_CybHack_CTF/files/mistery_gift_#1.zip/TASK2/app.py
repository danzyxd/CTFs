import os

from flask import Flask, request, render_template, redirect, url_for, flash, make_response, jsonify, send_file
from flask_jwt_extended import (create_access_token, get_jwt_identity, jwt_required, JWTManager, set_access_cookies,
                                verify_jwt_in_request)
from conect_to_database import connect_to_database

app = Flask(__name__)
app.secret_key = ''
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER




connection = connect_to_database()

app.config['JWT_COOKIE_CSRF_PROTECT'] = False
FLAG = os.getenv('FLAG')
jwt = JWTManager(app)


@app.route('/')
def main_page():
    return render_template('index.html')


@app.route('/register', methods=['POST', 'GET'])
def register_user():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password != confirm_password:
            flash('пароли не совпадают')
            return redirect(url_for('register_user'))
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            existing_user = cursor.fetchone()
        if existing_user:
            flash('пользователь с таким именем уже существует')
            return redirect(url_for('register_user'))
        with connection.cursor() as cursor:
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
            cursor.connection.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM users WHERE username = '{username}' and password = '{password}'")
            user = cursor.fetchone()
        if user:
            access_token = create_access_token(identity=user[1])
            response = make_response(redirect(url_for('home')))
            set_access_cookies(response, access_token)
            return response
        else:
            flash('Неверное имя пользователя или пароль', 'error')

    return render_template('login.html')


@app.route('/get_gift')
@jwt_required(locations=['cookies'])
def download_file():
    filename = request.args.get('filename', 'gift.jpg')
    file_path = f"uploads/{filename}"
    return send_file(file_path)

@app.route('/home')
@jwt_required(locations=['cookies'])
def home():
    current_user = get_jwt_identity()
    if current_user == 'admin':
        return render_template('admin.html', flag=FLAG)
    return render_template('home.html', current_user=current_user)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
