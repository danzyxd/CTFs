import os

import psycopg2


def connect_to_database():
    connection = None
    try:
        connection = psycopg2.connect(
            host='db',
            user=os.getenv('POSTGRES_USER'),
            password=os.getenv('POSTGRES_PASSWORD'),
            database=os.getenv('POSTGRES_DB'),
        )
        return connection
    except Exception as e:
        print(f"An error occurred while connecting to the database: {e}")
        raise
